#ifndef TESTDECORATOR_H
#define TESTDECORATOR_H

#pragma once
#include "testable.h"

class TestDecorator : public Testable {
private:
    Testable* internalTest;

public:
    TestDecorator(Testable* test);
    virtual ~TestDecorator();

    Testable* getInternalTest();
    void setInternalTest(Testable* test);

    virtual bool runTest() override;
};

#endif