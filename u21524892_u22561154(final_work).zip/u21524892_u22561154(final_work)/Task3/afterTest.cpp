#include "afterTest.h"
#include "testable.h"
#include "testDecorator.h"

#include <string>
#include <iostream>

using namespace std;

AfterTest::AfterTest(Testable* test, const std::string& message) : TestDecorator(test), afterMessage(message) {}

bool AfterTest::runTest() {
    bool result = TestDecorator::runTest();
    std::cout << "After Test: " << afterMessage << std::endl;
    return result;
}
