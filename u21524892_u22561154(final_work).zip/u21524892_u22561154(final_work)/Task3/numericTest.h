#ifndef NUMERICTEST_H
#define NUMERICTEST_H

#pragma once
#include "test.h"

class NumericTest : public Test {
public:
    virtual bool executeTest();
    virtual bool runTest() override;
    virtual ~NumericTest();
};

#endif