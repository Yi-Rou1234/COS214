#include "testDecorator.h"

TestDecorator::TestDecorator(Testable* test) : internalTest(test) {}

TestDecorator::~TestDecorator() {
    // delete internalTest;
}

Testable* TestDecorator::getInternalTest() {
    return internalTest;
}

void TestDecorator::setInternalTest(Testable* test) {
    internalTest = test;
}

bool TestDecorator::runTest() {
    return internalTest->runTest();
}