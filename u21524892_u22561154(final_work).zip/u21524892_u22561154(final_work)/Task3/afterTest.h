#ifndef AFTERTEST_H
#define AFTERTEST_H

#pragma once
#include "afterTest.h"
#include "testable.h"
#include "testDecorator.h"

#include <string>
#include <iostream>

using namespace std;

class AfterTest : public TestDecorator {
private:
    std::string afterMessage;

public:
    AfterTest(Testable* test, const std::string& message);
    virtual bool runTest() override;
};

#endif