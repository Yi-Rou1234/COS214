#include "calculator.h"
#include <iostream>

std::string Calculator::getInputString() {
    return inputString;
}

void Calculator::setInputString(const std::string& inputString) {
    this->inputString = inputString;
}

void Calculator::performCalculation() {
    // Implement your calculation logic here
}
