#include "testDecorator.h"
#include "beforeTest.h"
#include "afterTest.h"
#include "testBed.h"
#include "test.h"
#include "numericTest.h"
#include "booleanCalculator.h"

#include <iostream>

class ConcreteTest : public Testable {
public:
    virtual bool runTest() override {
        std::cout << "Executing ConcreteTest" << std::endl;
        return true;  // Placeholder return value
    }
};

class ConcreteTest2 : public Testable {
public:
    virtual bool runTest() override {
        std::cout << "Executing ConcreteTest2" << std::endl;
        return true;  // Placeholder return value
    }
};

int main() {
    ConcreteTest* concreteTest = new ConcreteTest();
    
    BeforeTest* before = new BeforeTest(concreteTest, "Before message");
    AfterTest* after = new AfterTest(before, "After message");
    
    TestBed* testBed = new TestBed(after);
    testBed->runTest();

    ConcreteTest2* numTest = new ConcreteTest2();  // Using a different class name
    
    NumericTest* num = new NumericTest();
    BooleanTest* boolean = new BooleanTest();

    TestBed* numBed = new TestBed(num);
    TestBed* boolBed = new TestBed(boolean);
    numBed->runTest();
    boolBed->runTest();

    delete numBed;
    delete boolBed;
    delete testBed;
    return 0;
}
