#ifndef BEFORETEST_H
#define BEFORETEST_H

#pragma once
#include "testDecorator.h"

#include <string>
#include <iostream>

using namespace std;

class BeforeTest : public TestDecorator {
private:
    std::string beforeMessage;

public:
    BeforeTest(Testable* test, const std::string& message);
    virtual bool runTest() override;
};

#endif