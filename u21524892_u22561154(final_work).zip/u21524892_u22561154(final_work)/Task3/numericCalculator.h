#ifndef NUMERICCALCULATOR_H
#define NUMERICCALCULATOR_H

#pragma once
#include "calculator.h"
#include "numericTest.h"

class NumericCalculator : public Calculator {
private:
    NumericTest* test;

public:
    NumericCalculator(NumericTest* test);
    virtual ~NumericCalculator();

    void runNumericTest();
};

#endif