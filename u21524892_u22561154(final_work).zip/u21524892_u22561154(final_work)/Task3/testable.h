#ifndef TESTABLE_H
#define TESTABLE_H

#pragma once

class Testable {
public:
    virtual bool runTest() = 0;
};

#endif