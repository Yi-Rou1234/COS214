#ifndef BOOLEANTEST_H
#define BOOLEANTEST_H

#pragma once
#include "test.h"

class BooleanTest : public Test {
public:
    virtual bool executeTest();
    virtual bool runTest() override;
    virtual ~BooleanTest();
};

#endif