#ifndef TESTBED_H
#define TESTBED_H

#pragma once
#include "testable.h"

class TestBed {
private:
    Testable* test;

public:
    TestBed(Testable* test);
    virtual ~TestBed();

    Testable* getTest();
    void setTest(Testable* test);

    bool runTest();
};

#endif