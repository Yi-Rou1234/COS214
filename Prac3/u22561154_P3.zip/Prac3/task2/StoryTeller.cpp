#include "Storyteller.h"

Storyteller::Storyteller() {
    waveDefeated = false;
}

void Storyteller::createWaveOfHeroes() {
}

void Storyteller::simulateHeroActions() {
}

bool Storyteller::isWaveDefeated() {
    return waveDefeated;
}
